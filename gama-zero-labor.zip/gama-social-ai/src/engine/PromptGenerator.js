/**
 * PromptGenerator.js — Gama Distribuidora
 * Gera prompts em PT-BR para ferramentas de IA (imagem/vídeo).
 * SEM referências à Labor Atacadista.
 */

const FORMAT_SPECS = {
  reels:        { aspect: '9:16', resolution: '1080x1920', notes: 'vertical, mobile, texto em destaque' },
  carrossel:    { aspect: '1:1',  resolution: '1080x1080', notes: 'quadrado, layout limpo, texto legível' },
  stories:      { aspect: '9:16', resolution: '1080x1920', notes: 'vertical, tela cheia, elementos interativos' },
  post_estatico:{ aspect: '1:1',  resolution: '1080x1080', notes: 'quadrado, alto contraste, cores da marca' },
  banner_site:  { aspect: '3:1',  resolution: '1200x400',  notes: 'horizontal, otimizado desktop, botão CTA' },
  whatsapp:     { aspect: '1:1',  resolution: '600x600',   notes: 'compacto, mobile, carregamento rápido' },
};

export const PromptGenerator = {

  generate({ name, category, format = 'reels', catContext }) {
    const spec = FORMAT_SPECS[format] || FORMAT_SPECS.reels;
    const keywords = catContext?.keywords || ['qualidade', 'distribuidor oficial'];
    const visual = catContext?.visual_cue || 'produto em ambiente profissional';

    return {
      studio: `Fotografia profissional de produto: ${name}. Iluminação de estúdio, sombras suaves, fundo branco clean. Produto centralizado, formato ${spec.aspect}. Categoria: ${category}. Ultra detalhado, qualidade comercial.`,
      lifestyle: `Foto realista: ${name} em loja de tintas e materiais de construção no Brasil. Lojista confiante manuseando o produto no balcão. Prateleiras organizadas com produtos Coral ao fundo. Iluminação natural, formato ${spec.aspect}. Autêntico, não encenado.`,
      institutional: `Fotografia corporativa: centro de distribuição moderno da Gama Distribuidora. Armazém organizado com produtos ${category} em prateleiras industriais. Paleta de cores azul marinho e laranja da Gama. Grande São Paulo e Baixada Santista. Iluminação profissional, atmosfera de confiança. Formato ${spec.aspect}.`,
      format_spec: spec,
    };
  },

  generateFull({ name, category, catContext }) {
    const visual = catContext?.visual_cue || `${name} em ambiente profissional`;
    const keywords = catContext?.keywords || ['qualidade', 'distribuidor oficial Coral'];
    const packs = {};

    Object.entries(FORMAT_SPECS).forEach(([fmt, spec]) => {
      packs[fmt] = {
        format: fmt,
        spec,
        prompts: {
          studio: {
            label: '📷 Foto de Estúdio',
            prompt_pt: `Fotografia hiper-realista de produto: ${name}. Iluminação de estúdio profissional, sombras suaves, fundo branco clean. Produto centralizado em superfície minimalista. Formato ${spec.aspect}, ${spec.resolution}. Categoria: ${category}. Ultra detalhado, qualidade 8K.`,
          },
          lifestyle: {
            label: '🏪 Lifestyle B2B (Loja)',
            prompt_pt: `Foto realista profissional: ${name} em loja de tintas brasileira. Lojista (40 anos, confiante) manuseando o produto no balcão. Fundo: prateleiras organizadas com produtos Coral — latas retangulares azul marinho e laranja. Iluminação natural quente. Formato ${spec.aspect}. Cena autêntica.`,
          },
          institutional: {
            label: '🏢 Institucional Gama',
            prompt_pt: `Fotografia corporativa: Gama Distribuidora, distribuidora oficial Coral/AkzoNobel. Armazém moderno com produtos ${category} em prateleiras industriais organizadas. Cores da marca: azul marinho (#2D2D6B) e laranja. Grande São Paulo e Baixada Santista ao fundo. Iluminação profissional, atmosfera de solidez e confiança. Formato ${spec.aspect}.`,
          },
          coral_product: {
            label: '🎨 Produto Coral em Destaque',
            prompt_pt: `Foto publicitária de lata Coral: ${name}. Lata retangular moderna com cantos arredondados, alças laterais metálicas, tampa com alça circular embutida. Design azul marinho com logo Coral colorido. Superfície clean, iluminação dramática lateral. Reflexo suave. Formato ${spec.aspect}. Qualidade comercial premium.`,
          },
          video: {
            label: '🎬 Vídeo / B-Roll',
            prompt_pt: `Filmagem B-roll cinematográfica: ${visual}. Câmera lenta elegante. Formato ${spec.aspect}. Gradação de cor profissional em tons azul marinho e laranja. Profundidade de campo rasa. Ambiente de loja de tintas e materiais de construção brasileira.`,
          },
        },
      };
    });

    return { name, category, keywords, packs, generatedAt: Date.now() };
  },
};
