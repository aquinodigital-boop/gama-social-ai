import React, { useState } from 'react';
import { ProductSelector } from './components/ProductSelector';
import { ContentGenerator } from './components/ContentGenerator';
import { ErrorBoundary } from './components/ui/ErrorBoundary';
import { ToastProvider } from './components/ui/Toast';

function App() {
  const [selectedItem, setSelectedItem] = useState(null);
  const [logoError, setLogoError] = useState(false);

  return (
    <ToastProvider>
      <ErrorBoundary>
        <div className="app-root">
          <header className="labor-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', width: '100%' }}>
              {!logoError ? (
                <img
                  src="/gama-logo.jpg"
                  alt="Gama Distribuidora"
                  className="header-logo"
                  onError={() => setLogoError(true)}
                />
              ) : (
                <div className="header-brand-mark">
                  <span className="header-brand-g">G</span>
                </div>
              )}
              <span className="header-divider"></span>
              <div className="header-title-group">
                <span className="header-app-name">Laboratório de Conteúdo</span>
                <span className="tagline">Gama Distribuidora · Distribuidor Oficial Coral/AkzoNobel</span>
              </div>
              <div className="header-badge" style={{ marginLeft: 'auto' }}>
                <span>🎨 20 anos</span>
              </div>
            </div>
          </header>

          <div className="app-layout">
            <ProductSelector
              onSelect={(product) => setSelectedItem(product)}
              onCategorySelect={(cat) => setSelectedItem(cat)}
              onBrandSelect={(brand) => setSelectedItem(brand)}
              selectedItem={selectedItem}
            />
            <ErrorBoundary>
              <ContentGenerator item={selectedItem} />
            </ErrorBoundary>
          </div>
        </div>
      </ErrorBoundary>
    </ToastProvider>
  );
}

export default App;
