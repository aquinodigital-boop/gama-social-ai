/**
 * GamaDataService.js (mantido como LaborDataService para compatibilidade)
 * Categorias de produtos Coral/Gama para o gerador de conteúdo.
 */

const GAMA_CATEGORIES = [
  "Tintas Internas",
  "Tintas Externas",
  "Tintas de Piso",
  "Vernizes e Tingidores",
  "Texturas e Revestimentos",
  "Massa Corrida e Selador",
  "Impermeabilizantes",
  "Tintometria / Tinting",
  "Ferramentas de Pintura",
  "Hidráulica",
  "Adesivos e Fixação",
  "Abrasivos e Lixas",
  "Argamassas e Rejuntes",
];

const SAMPLE_PRODUCTS = [
  { name: "Coralar 18L", category: "Tintas Internas" },
  { name: "Decora Premium Branco 18L", category: "Tintas Internas" },
  { name: "Proteção Sol & Chuva 18L", category: "Tintas Externas" },
  { name: "Rende Muito 18L", category: "Tintas Internas" },
  { name: "Pinta Piso Cinza 18L", category: "Tintas de Piso" },
  { name: "Verniz Sparlack Acetinado 0,9L", category: "Vernizes e Tingidores" },
  { name: "Verniz Sparlack Marítimo 0,9L", category: "Vernizes e Tingidores" },
  { name: "Tingidor Madeira Ipê Sparlack", category: "Vernizes e Tingidores" },
  { name: "Textura Mactra Rústica Branca 25kg", category: "Texturas e Revestimentos" },
  { name: "Grafiato Mactra 25kg", category: "Texturas e Revestimentos" },
  { name: "Massa Corrida PVA Coral 25kg", category: "Massa Corrida e Selador" },
  { name: "Selador Acrílico Coral 18L", category: "Massa Corrida e Selador" },
  { name: "Impermeabilizante Viapol 18L", category: "Impermeabilizantes" },
  { name: "Base Branca Tinting 18L", category: "Tintometria / Tinting" },
  { name: "Rolo Lã de Carneiro 23cm Tramontina", category: "Ferramentas de Pintura" },
  { name: "Trincha 2\" Tramontina", category: "Ferramentas de Pintura" },
  { name: "Bandeja para Rolo Tramontina", category: "Ferramentas de Pintura" },
  { name: "Lixa Massa Norton 120 grit", category: "Abrasivos e Lixas" },
  { name: "Lixa Madeira Norton 80 grit", category: "Abrasivos e Lixas" },
  { name: "Silicone Neutro Henkel Branco", category: "Adesivos e Fixação" },
  { name: "Cola de Contato Henkel 750g", category: "Adesivos e Fixação" },
  { name: "Tubo PVC Tigre 100mm", category: "Hidráulica" },
  { name: "Rejunte Flex Viapol Branco 1kg", category: "Argamassas e Rejuntes" },
];

export const LaborDataService = {
  getUniqueCategories: () => GAMA_CATEGORIES,
  getProducts: () => SAMPLE_PRODUCTS,
  identifyCategory: (productName) => {
    const name = productName.toLowerCase();
    if (name.includes("verniz") || name.includes("tingidor")) return "Vernizes e Tingidores";
    if (name.includes("textura") || name.includes("grafiato")) return "Texturas e Revestimentos";
    if (name.includes("massa") || name.includes("selador")) return "Massa Corrida e Selador";
    if (name.includes("imperme")) return "Impermeabilizantes";
    if (name.includes("piso")) return "Tintas de Piso";
    if (name.includes("externo") || name.includes("fachada") || name.includes("sol")) return "Tintas Externas";
    if (name.includes("rolo") || name.includes("trincha") || name.includes("bandeja")) return "Ferramentas de Pintura";
    if (name.includes("lixa")) return "Abrasivos e Lixas";
    if (name.includes("silicone") || name.includes("cola")) return "Adesivos e Fixação";
    if (name.includes("tubo") || name.includes("pvc")) return "Hidráulica";
    if (name.includes("rejunte") || name.includes("argamassa")) return "Argamassas e Rejuntes";
    return "Tintas Internas";
  }
};
